========================
Lasso in other Languages
========================

C is cool.

But.

Python. (CGI ?)

PHP. (with code putting the session dump in the PHP $_SESSION["lasso"])

Java. (and JSP ?)

C#. (and ASP.Net ?)

Whatever we have.

