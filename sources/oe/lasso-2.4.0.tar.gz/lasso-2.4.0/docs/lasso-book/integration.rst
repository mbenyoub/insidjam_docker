======================================
Integration with Existing Applications
======================================

That's the part where we talk about identity dumps to insert in existing user
tables.  And session dumps wherever sessions are stored.

