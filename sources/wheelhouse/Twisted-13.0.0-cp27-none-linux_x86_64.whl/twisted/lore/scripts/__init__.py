"lore scripts"
