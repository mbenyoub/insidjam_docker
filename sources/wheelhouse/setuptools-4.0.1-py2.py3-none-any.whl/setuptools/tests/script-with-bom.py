﻿# -*- coding: utf-8 -*-

result = 'passed'
