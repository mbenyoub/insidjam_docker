Chameleon templating system Bindings for Pyramid
=================================================

These are bindings for the `Chameleon templating system
<http://pagetemplates.org/>`_ for the Pyramid_ web framework.  See
http://docs.pylonsproject.org/projects/pyramid_chameleon/en/latest/ for
documentation.

.. _Pyramid: http://docs.pylonshq.com/


0.1
---

-  Initial version


