Introduction
============

Useful tools library with classes to do singletons, dynamic function pointers...


