A note on the included libraries
================================

The following libraries have been patched to prevent conflicts with the
applications that include this toolbar. If these libraries are upgraded they
must be re-patched.

- require.js
- jquery-1.7.2.min.js
