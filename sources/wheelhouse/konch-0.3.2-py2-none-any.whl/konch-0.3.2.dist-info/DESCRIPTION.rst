Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
Description: =====
        konch
        =====
        
        
        Configures your Python shell
        ============================
        
        **konch** is a CLI and configuration utility for the Python shell, optimized for simplicity and productivity.
        
        - **Automatically import** any object upon startup
        - **Simple**, per-project configuration in a single file (it's just Python code)
        - **No dependencies**
        - Uses **IPython** and **BPython** if available, and falls back to built-in interpreter
        - Can have multiple configurations per project using **named configs**
        
        .. image:: https://dl.dropboxusercontent.com/u/1693233/github/konch-030-demo-optim.gif
            :alt: Demo
            :target: http://konch.readthedocs.org
        
        
        `http://konch.readthedocs.org <http://konch.readthedocs.org>`_
        ==============================================================
        
        
        
        *********
        Changelog
        *********
        
        0.3.2 (2014-03-18)
        ------------------
        
        - Some changes to make it easier to use konch programatically.
        - ``konch.start()`` can be called with no arguments.
        - Expose docopt argument parsing via ``knoch.parse_args()``.
        
        
        0.3.1 (2014-03-17)
        ------------------
        
        - Doesn't change current working directory.
        - Less magicks.
        - Tested on Python 3.4.
        
        
        0.3.0 (2014-03-16)
        ------------------
        
        - Smarter path resolution. konch will search parent directories until it finds a .konchrc file to use.
        - Make prompt configurable on IPython and built-in shell. Output template is also supported on IPython.
        - *Backwards-incompatible*: Remove support for old (<=0.10.x--released 3 years ago!) versions of IPython.
        
        0.2.0 (2014-03-15)
        ------------------
        
        - Fix bug with importing modules and packages in the current working directory.
        - Introducing *named configs*.
        
        0.1.0 (2014-03-14)
        ------------------
        
        - First release to PyPI.
        
Keywords: konch shell custom ipython bpython repl
Platform: UNKNOWN
Classifier: Development Status :: 2 - Pre-Alpha
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved :: MIT License
Classifier: Natural Language :: English
Classifier: Programming Language :: Python :: 2
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.3
Classifier: Programming Language :: Python :: 3.4
Classifier: Programming Language :: Python :: Implementation :: CPython
Classifier: Programming Language :: Python :: Implementation :: PyPy
