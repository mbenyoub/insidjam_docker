import os


editor = r'q:/opt/np/notepad++.exe'


e = os.environ

e['EDITOR'] = editor
e['VISUAL'] = editor





