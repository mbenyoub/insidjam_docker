Argh: The Natural CLI
=====================

Building a command-line interface?  Found yourself uttering "argh!" while
struggling with the API of `argparse`?  Don't want to lose its power but don't
need the complexity?

.. epigraph::

    Everything should be made as simple as possible, but no simpler.

    -- Albert Einstein (probably)

`Argh` provides a wrapper for `argparse`.  `Argparse` is a very powerful tool;
`Argh` just makes it easy to use.

In a nutshell
-------------

`Argh`-powered applications are *simple* but *flexible*:

:Modular:
    Declaration of commands can be decoupled from assembling and dispatching;

:Pythonic:
    Commands are declared naturally, no complex API calls in most cases;

:Reusable:
    Commands are plain functions, can be used directly outside of CLI context;

:Layered:
    The complexity of code raises with requirements;

:Transparent:
    The full power of argparse is available whenever needed;

:Namespaced:
    Nested commands are a piece of cake, no messing with subparsers (though
    they are of course used under the hood);

:Term-Friendly:
    Command output is processed with respect to stream encoding;

:Unobtrusive:
    `Argh` can dispatch a subset of pure-`argparse` code, and pure-`argparse`
    code can update and dispatch a parser assembled with `Argh`;

:DRY:
    The amount of boilerplate code is minimal; among other things, `Argh` will:

    * infer command name from function name;
    * infer arguments from function signature;
    * infer argument type from the default value;
    * infer argument action from the default value (for booleans);
    * add an alias root command ``help`` for the ``--help`` argument.

Sounds good?  Check the tutorial!

Relation to argparse
--------------------

`Argh` is fully compatible with `argparse`.  You can mix `Argh`-agnostic and
`Argh`-aware code.  Just keep in mind that the dispatcher does some extra work
that a custom dispatcher may not do.

Installation
------------

Using pip::

    $ pip install argh

Arch Linux (AUR)::

    $ yaourt python-argh

Examples
--------

A very simple application with one command:

.. code-block:: python

    import argh

    def main():
        return 'Hello world'

    argh.dispatch_command(main)

A potentially modular application with multiple commands:

.. code-block:: python

    import argh

    # declaring:

    def echo(text):
        return text

    def greeter(name, greeting='hello'):
        return greeting + ', ' + name

    # assembling:

    parser = argh.ArghParser()
    parser.add_commands([echo, greeter])

    # dispatching:

    if __name__ == '__main__':
        parser.dispatch()

The powerful API of `argparse` is also available:

.. code-block:: python

    @arg('text', default='hello world', nargs='+', help='The message')
    def echo(text):
        print text

The approaches can be safely combined even up to this level:

.. code-block:: python

    # adding help to `foo` which is in the function signature:
    @arg('foo', help='blah')
    # these are not in the signature so they go to **kwargs:
    @arg('baz')
    @arg('-q', '--quux')
    # the function itself:
    def cmd(foo, bar=1, *args, **kwargs):
        yield foo
        yield bar
        yield ', '.join(args)
        yield kwargs['baz']
        yield kwargs['quux']

Links
-----

* `Project home page`_ (Bitbucket)
* `Documentation`_ (Read the Docs)
* `Package distribution`_ (PyPI)
* Questions, requests, bug reports, etc.:

  * `Issue tracker`_
  * `Mailing list`_ (subscribe to get important announcements)
  * Direct e-mail (neithere at gmail com)
  * Twitter_ (to get notified of commits; mostly for lulz)

.. _project home page: http://github.com/neithere/argh/
.. _documentation: http://argh.readthedocs.org
.. _package distribution: http://pypi.python.org/pypi/argh
.. _issue tracker: http://github.com/neithere/argh/issues/
.. _mailing list: http://groups.google.com/group/argh-users
.. _twitter: http://twitter.com/python_argh

Author
------

Developed by Andrey Mikhaylenko since 2010.

See file `AUTHORS` for a complete list of contributors to this library.

Licensing
---------

Argh is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Argh is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with Argh.  If not, see <http://gnu.org/licenses/>.


